import 'package:flutter/material.dart';
import 'package:chatbot/screens/chat_screen.dart'; // Ensure the path is correct

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: ChatScreen(), // Load chatbot instead of counter app
    );
  }
}
